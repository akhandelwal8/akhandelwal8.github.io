October 23, 2013
Amit K Khandelwal

Ahn, JaeBin, Amit K Khandelwal and Shang-Jin Wei (2011). "The Role of Intermediaries in Facilitating Trade," Journal of International Economics, 84(1), 73-85.

This zip file contains the share of China's exports sent by intermediaries in 2005, by HS2, HS4 and HS6. Please consult the paper for the definition of intermediary firms in the Chinese customs data. If you use these data, please cite