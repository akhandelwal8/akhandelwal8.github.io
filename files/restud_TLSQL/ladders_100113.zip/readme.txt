2010.01.10

Description of Quality Ladder Measures for "Long and Short (of) Quality Ladders" by Amit K. Khandelwal (forthcoming in Review of Economic Studies)

ladder_hs10_rep.dta

This file contains quality ladder measures at the 10-digit HS level. The data in this dataset have the following layout:

hs		10-digit hs code
sic87		four-digit sic code (1987 revision)
init_value	Initial period total real value of the HS code.
ladder		quality ladder defined in eq. 18.


ladder_sic87_rep.dta

This file contains quality ladder measures at the 10-digit HS level. The data in this dataset have the following layout:

sic87		four-digit sic code (1987 revision)
ladder_sic87	quality ladder defined in eq. 20.




The SIC industry-level quality ladders in ladder_sic87_rep.dta are created by running the the following code in ladder_hs10_rep.dta:


	bys sic87: egen totv = sum(init_value)
	g shv = init_value/totv

	/* before aggregating the ladders, take the anti-log and weigh by initial value */
	replace ladder = exp(ladder) - 1
	g ladder_sic87 = shv * ladder
	
	/* aggregate to sic87 level */
	collapse (sum) ladder_sic87, by(sic87)
	replace ladder_sic87 = log(ladder_sic87)
	

If you use these data, please cite:
	
	Khandelwal, Amit K. "The Long and Short (of) Quality Ladders." forthcoming Review of Economic Studies.

If you encounter any problems with these data, please let me know via email at ak2796@columbia.edu.
